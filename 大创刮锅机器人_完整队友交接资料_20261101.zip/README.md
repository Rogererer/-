# 月饼馅料刮锅机器人

项目资料与两种刮锅动作的概念动画，供团队协作和厂家方案讨论。

## 动画

- [方案一：锅固定，机械臂刮扫一整圈](scheme_1_full_circle.mp4)
- [方案二：刮半圈、锅转 180°、再刮半圈](scheme_2_half_rotate_half.mp4)

## 仿真文件

- [仿真说明、模型来源和重建步骤](simulation_v2/README.md)
- [两方案关节轨迹](simulation_v2/motion.json)
- [动画生成与轨迹检查脚本](simulation_v2/render_animation.py)
- [IGV 尺寸占位 CAD](igv_model/AMB-CSW04-SR_IGV_simplified.step)
- 锅装配体原始压缩包：`simulation_v2/source_cad/kettle_assembly_original.zip`

## 当前状态

动画采用 JAKA 官方 A20 关节模型和连杆网格，以及可由当前 SolidWorks 打开的搅拌机构几何。锅体零件在 SolidWorks 2024 中因版本过新无法读取，因此动画里的锅体仍按图纸尺寸占位；拿到完整锅体 STEP 后，需要更新布局和碰撞检查。
