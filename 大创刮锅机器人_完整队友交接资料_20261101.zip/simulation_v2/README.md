# 刮锅机器人两方案概念动画

## 内容

- `../scheme_1_full_circle.mp4`：锅固定，机械臂沿锅内侧环形路径刮扫 360°。
- `../scheme_2_half_rotate_half.mp4`：先刮近侧半圈，抬刀，锅绕中心竖直轴旋转 180°，重新入锅后刮扫剩余区域。
- `motion.json`：按采样点保存的关节角、末端位置和目标点。
- `solve_motion.py`：按 A20 官方 URDF 关节链和角度限位求逆运动学。
- `render_animation.py`：用 A20 STL 连杆和 SolidWorks 导出的搅拌机构生成 MP4。
- `validate_motion.py`：检查关节限位、视频帧间速度、TCP 路径误差及连杆与占位锅体的穿透。
- `stirrer_partial_from_SOLIDWORKS.step/.stl`：SolidWorks 2024 从目前成功加载的装配部分另存导出，包含 9 个实体。
- `a20_official/`：JAKA 官方 A20 URDF 和 7 个连杆 STL。
- `source_cad/kettle_assembly_original.zip`：锅装配体原始压缩包，供有更新版本 SolidWorks 的队员继续打开和导出。

## 模型来源与假设

| 部件 | 来源/状态 |
|---|---|
| JAKA A20 机械臂 | JAKA Robotics 官方 `jaka_ros2` 仓库中的 `jaka_a20.urdf` 与 STL 网格；原仓库链接：[jaka_description](https://github.com/JAKARobotics/jaka_ros2/tree/main/src/jaka_description) |
| 搅拌机构 | 用户提供的 SolidWorks 装配体中当前可加载部分；导出 STEP 供动画使用 |
| 锅体 | `零件2.SLDPRT` 在 SolidWorks 2024 报“将来的版本”，无法读取；动画按图纸尺寸建立占位几何 |
| IGV | 按所给外形图尺寸 816×545×230 mm 建立占位 CAD，不是仙工正式 CAD |
| 刮刀与安装立柱 | 动作及布局概念件，尚未工程设计 |

本次坐标和尺寸：锅内半径 0.65 m，锅沿高 1.05 m，锅底高 0.55 m；刮扫半径 0.59 m、高 0.95 m；A20 安装面中心 `(-0.98,0,1.15)` m；法兰到刮刀端点按 0.20 m 示意。第二方案假设锅能绕中心竖直轴定位转 180°。

## 检查结论和边界

视频的关节角在 URDF 限位内；按 16 fps 插值的关节速度低于 URDF 最大速度；刮刀目标轨迹最大误差约 3.8 mm（方案一）和 1.7 mm（方案二）。A20 连杆与占位锅内表面的采样检查未发现穿透。

这仍是运动学概念动画，锅体和 IGV 不是供应商完整 CAD。锅内障碍、安装结构、刮刀几何、高温保护、载荷、加速度和锅的真实转动机构均未验证，不能作为生产轨迹或最终避障证明。屏幕中的播放时长也未按真实工艺节拍设定。

## 重建

Python 3.12 环境安装依赖：

```powershell
python -m pip install numpy scipy Pillow imageio-ffmpeg trimesh fast-simplification
```

在仓库根目录运行：

```powershell
python simulation_v2/solve_motion.py
python simulation_v2/validate_motion.py
python simulation_v2/render_animation.py
```

输出视频写入仓库根目录，与现有两个动画文件同名覆盖。需要先备份自行修改过的输出。

## 下一步

请锅设备厂家或拥有较新 SolidWorks 的队员，将完整 `装配体2.SLDASM`（含锅体）另存为 STEP AP214/AP242，并补充锅旋转轴位置、定位精度、最大转速和搅拌机构停放位置。收到后重新装配、校准坐标并复核干涉。
