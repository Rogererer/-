"""Render review videos from JAKA A20 STL links and SolidWorks-exported stirrer.

The bowl and IGV are dimension-based placeholders.  Output is a motion concept,
not an engineering collision certificate.
"""
import json
import math
from pathlib import Path
import struct
import subprocess

import numpy as np
from PIL import Image, ImageDraw, ImageFont
from solve_motion import fk, solve, tool
import imageio_ffmpeg

HERE=Path(__file__).parent
DATA=json.loads((HERE/'motion.json').read_text(encoding='utf-8'))
OUT=HERE/'output'; OUT.mkdir(exist_ok=True)
W,H=960,650
CAM=np.array([2.7,-3.6,3.0]); TARGET=np.array([0.,0.,1.25]);
forward=(TARGET-CAM); forward/=np.linalg.norm(forward)
right=np.cross(forward,np.array([0.,0.,1.])); right/=np.linalg.norm(right)
up=np.cross(right,forward)
SCALE=185

def read_stl(p, max_faces=800):
    import trimesh
    p=Path(p); cache=HERE/(p.stem+f'_{max_faces}.npy')
    if cache.exists(): return np.load(cache)
    mesh=trimesh.load_mesh(p,process=True)
    if len(mesh.faces)>max_faces:
        mesh=mesh.simplify_quadric_decimation(face_count=max_faces)
    faces=np.asarray(mesh.triangles,dtype=np.float64)
    np.save(cache,faces)
    return faces

LINKS=[read_stl(HERE/'a20_official'/'meshes'/(('base_link' if i==0 else f'Link_0{i}')+'.STL'),2400 if i in (0,2,3) else 1500) for i in range(7)]
STIR=read_stl(HERE/'stirrer_partial_from_SOLIDWORKS.stl',1800)/1000.

def transform(faces,m): return faces@m[:3,:3].T+m[:3,3]

def projection(p):
    delta=p-TARGET
    return np.stack((W*.45+SCALE*(delta@right), H*.53-SCALE*(delta@up)),axis=-1)

def font(size=24):
    for p in (r'C:\Windows\Fonts\msyh.ttc',r'C:\Windows\Fonts\simhei.ttf'):
        if Path(p).exists(): return ImageFont.truetype(p,size)
    return ImageFont.load_default()

F_TITLE=font(30); F_BODY=font(20); F_SMALL=font(16)

def draw_mesh(draw, faces, color):
    if len(faces)==0:return
    centers=faces.mean(axis=1)
    depths=(centers-CAM)@forward
    order=np.argsort(depths)[::-1]
    tri=projection(faces)
    normals=np.cross(faces[:,1]-faces[:,0],faces[:,2]-faces[:,0])
    norms=np.linalg.norm(normals,axis=1)+1e-9
    light=np.array([-0.2,-0.55,0.81]); light/=np.linalg.norm(light)
    brightness=.56+.38*np.abs((normals@light)/norms)
    for j in order:
        c=tuple(int(np.clip(x*brightness[j],0,255)) for x in color)
        draw.polygon([tuple(map(float,v)) for v in tri[j]],fill=c)

def poly_box(center, dims):
    x,y,z=center; a,b,c=np.array(dims)/2
    pts=np.array([[x+i*a,y+j*b,z+k*c] for i in [-1,1] for j in [-1,1] for k in [-1,1]])
    faceids=[[0,2,3,1],[4,5,7,6],[0,1,5,4],[2,6,7,3],[0,4,6,2],[1,3,7,5]]
    return np.array([pts[v] for v in faceids])

def draw_box(draw,center,dims,color):
    fs=poly_box(center,dims)
    # Split quads into triangles for same shading function.
    draw_mesh(draw,np.concatenate((fs[:,[0,1,2]],fs[:,[0,2,3]])),color)

def draw_world(draw, angle):
    # Floor and IGV dimensions are from supplied drawing, offset under A20.
    floor=np.array([[[-2.1,-1.9,0], [1.4,-1.9,0], [1.4,1.9,0]], [[-2.1,-1.9,0],[1.4,1.9,0],[-2.1,1.9,0]]])
    draw_mesh(draw,floor,(239,243,247))
    draw_box(draw,[-.98,0,.115],[.816,.545,.23],(57,79,97))
    draw_box(draw,[-.98,0,.69],[.38,.38,.92],(113,127,138))
    # Pot shell: a bowl of approximate 1300 mm inner diameter.  Back half is
    # shaded; front half remains open visually to expose the tip and links.
    outer=[]; inner=[]
    th=np.linspace(0,2*math.pi,49)
    rr=np.linspace(.08,.65,9)
    for i in range(len(rr)-1):
        for j in range(len(th)-1):
            r0,r1=rr[i:i+2]; t0,t1=th[j:j+2]
            def pt(r,t):return [r*math.cos(t),r*math.sin(t),.55+.50*(r/.65)**2]
            p0,p1,p2,p3=pt(r0,t0),pt(r1,t0),pt(r1,t1),pt(r0,t1)
            inner.extend([[p0,p1,p2],[p0,p2,p3]])
    draw_mesh(draw,np.array(inner),(197,207,215))
    for a,col in ((angle,(203,77,56)),(angle+math.pi,(65,122,170))):
        draw_box(draw,[.74*math.cos(a),.74*math.sin(a),1.045],[.18,.15,.055],col)
    # Rim, four guide rings, and a red rotation tick are drawn after meshes.
    for r in [.22,.42,.65]:
        p=np.array([[r*math.cos(t),r*math.sin(t),.55+.50*(r/.65)**2] for t in np.linspace(0,2*math.pi,100)])
        xy=projection(p); draw.line([tuple(x) for x in xy],fill=(105,128,142),width=2 if r<.65 else 5,joint='curve')
    tick=np.array([[.65*math.cos(angle),.65*math.sin(angle),1.06],[.78*math.cos(angle),.78*math.sin(angle),1.06]])
    draw.line([tuple(x) for x in projection(tick)],fill=(211,74,58),width=6)

def render(frame, scheme, index, total, pot_angle, phase, logical_index=None):
    img=Image.new('RGB',(W,H),(250,251,253)); d=ImageDraw.Draw(img)
    draw_world(d,pot_angle)
    li=index if logical_index is None else logical_index
    def arc(a,b,shift=0,color=(52,167,107)):
        if abs(a-b)<1e-4:return
        ang=np.linspace(a+shift,b+shift,max(3,int(abs(b-a)*35)))
        pts=np.array([[.59*math.cos(t),.59*math.sin(t),.955] for t in ang])
        d.line([tuple(x) for x in projection(pts)],fill=color,width=6,joint='curve')
    if scheme=='full':
        arc(-math.pi,-math.pi+2*math.pi*index/max(1,total-1))
    else:
        if li<37: arc(math.pi/2,math.pi/2+math.pi*li/36)
        else:
            arc(math.pi/2,3*math.pi/2,pot_angle)
            if li>=79:
                u=min(1,max(0,(li-79)/36))
                arc(3*math.pi/2,3*math.pi/2-math.pi*u)
    # SolidWorks source part: shown lifted clear of the scraping volume.
    stir=STIR+np.array([.20,1.13,1.72])
    draw_mesh(d,stir,(111,153,162))
    if frame is not None:
        mats=fk(np.array(frame['q']))
        for i,(mesh,m) in enumerate(zip(LINKS,mats)):
            draw_mesh(d,transform(mesh,m),(248,168,70) if i in (1,3,5) else (59,111,169))
        tip=np.array(frame['tip']); flange=mats[-1][:3,3]
        d.line([tuple(x) for x in projection(np.stack((flange,tip)))],fill=(202,70,54),width=11)
        xy=projection(tip); x,y=xy
        d.ellipse((x-8,y-8,x+8,y+8),fill=(232,58,43),outline='white',width=2)
    # Top status band, drawn after model for legibility.
    d.rounded_rectangle((20,17,920,112),radius=16,fill=(255,255,255),outline=(218,226,234),width=2)
    title='方案一：锅静止，机械臂刮扫一整圈' if scheme=='full' else '方案二：刮半圈，锅转 180°，再刮半圈'
    d.text((39,25),title,font=F_TITLE,fill=(27,48,69))
    d.text((41,72),f'{phase}   |   进度 {index+1}/{total}   |   锅角度 {pot_angle*180/math.pi:.0f}°',font=F_BODY,fill=(75,94,113))
    d.rounded_rectangle((20,568,925,630),radius=11,fill=(255,255,255),outline=(220,228,234),width=2)
    d.text((38,577),'蓝/橙：JAKA 官方 A20 零件   青色：SolidWorks 导出的搅拌机构',font=F_SMALL,fill=(52,68,83))
    d.text((38,602),'锅体与 IGV：按现有图纸尺寸占位；刮刀：概念件。缺少可读取的真实锅体。',font=F_SMALL,fill=(145,77,62))
    return img

def sequence(scheme):
    tr=next(x['frames'] for x in DATA['trajectories'] if x['scheme']==('full' if scheme=='full' else 'half'))
    if scheme=='full':
        return [(f,0.,'整圈刮扫') for f in tr]
    # Second spatial half repeats after pot has turned, giving full pot coverage.
    first=[(f,0.,'第一段：刮扫近侧半圈') for f in tr]
    last=tr[-1]; q0=np.array(last['q'])
    th=last['theta']
    parked_target=np.array([.80*math.cos(th),.80*math.sin(th),1.32])
    qpark,err=solve(parked_target,q0)
    def pose(q):
        p=tool(q)[0]
        return dict(q=q.tolist(),tip=p.tolist())
    lift=[(pose(q0+(qpark-q0)*u),0.,'第二段：刮刀退出锅沿') for u in np.linspace(0,1,12)[1:]]
    turn=[(pose(qpark),math.pi*i/20,'第三段：锅绕中心竖轴转动 180°') for i in range(1,21)]
    lower=[(pose(qpark+(q0-qpark)*u),math.pi,'第四段：刮刀重新入锅') for u in np.linspace(0,1,12)[1:]]
    second=[(f,math.pi,'第五段：刮扫剩余半圈') for f in tr[::-1]]
    return first+lift+turn+lower+second

def write_video(scheme):
    original=sequence(scheme); seq=[]
    for j,item in enumerate(original):
        seq.append(item)
        if j+1<len(original):
            nxt=original[j+1]; qa=np.array(item[0]['q']); qb=np.array(nxt[0]['q'])
            qm=(qa+qb)/2; pm=tool(qm)[0]
            seq.append((dict(q=qm.tolist(),tip=pm.tolist()),(item[1]+nxt[1])/2,item[2]))
    path=OUT/(('scheme_1_full_circle.mp4' if scheme=='full' else 'scheme_2_half_rotate_half.mp4'))
    exe=imageio_ffmpeg.get_ffmpeg_exe()
    proc=subprocess.Popen([exe,'-y','-f','rawvideo','-vcodec','rawvideo','-s',f'{W}x{H}','-pix_fmt','rgb24','-r','16','-i','-','-an','-vcodec','libx264','-pix_fmt','yuv420p','-crf','22',str(path)],stdin=subprocess.PIPE,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    try:
        for i,(f,ang,phase) in enumerate(seq):
            frame=render(f,scheme,i,len(seq),ang,phase,logical_index=i/2)
            if i==0 or i==len(seq)//2: frame.save(OUT/f'{scheme}_frame_{i:03d}.png')
            proc.stdin.write(frame.tobytes())
            if i%20==0: print(scheme,i,'/',len(seq),flush=True)
    finally:
        proc.stdin.close(); proc.wait()
    if proc.returncode: raise RuntimeError(f'ffmpeg exit {proc.returncode}')
    print(path,'bytes',path.stat().st_size,flush=True)

if __name__=='__main__':
    write_video('full'); write_video('rotate')
