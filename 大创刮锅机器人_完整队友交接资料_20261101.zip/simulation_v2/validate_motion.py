"""Numerical checks for the concept motion, including proxy bowl clearance."""
import json
from pathlib import Path
import xml.etree.ElementTree as ET
import numpy as np
from solve_motion import fk,joints,tool
from render_animation import LINKS,sequence,transform

report={}
for name in ('full','rotate'):
    keyseq=sequence(name)
    seq=[]
    for j,item in enumerate(keyseq):
        seq.append(item)
        if j+1<len(keyseq):
            nxt=keyseq[j+1]
            qa=np.array(item[0]['q']);qb=np.array(nxt[0]['q']);qm=(qa+qb)/2
            mid=dict(q=qm.tolist(),tip=tool(qm)[0].tolist())
            if 'target' in item[0] and 'target' in nxt[0]:
                mid['target']=((np.array(item[0]['target'])+np.array(nxt[0]['target']))/2).tolist()
            seq.append((mid,(item[1]+nxt[1])/2,item[2]))
    q=np.array([f['q'] for f,_,_ in seq]); err=[]; crossing=[]
    for k,(f,_,phase) in enumerate(seq):
        mats=fk(q[k]); bad=0
        for i in range(1,7):
            pts=transform(LINKS[i],mats[i]).reshape(-1,3)
            rad=np.linalg.norm(pts[:,:2],axis=1)
            surf=.55+.50*(rad/.65)**2
            bad+=int(np.count_nonzero((rad<.65)&(pts[:,2]<surf-.01)))
        if bad: crossing.append(dict(frame=k,points=bad,phase=phase))
        if 'target' in f:err.append(float(np.linalg.norm(np.array(f['tip'])-np.array(f['target']))))
    limits=np.array([[j['lo'],j['hi']] for j in joints])
    speeds=np.max(np.abs(np.diff(q,axis=0)),axis=0)*16
    allowed=np.array([float(j.find('limit').attrib['velocity']) for j in ET.parse(Path(__file__).parent/'a20_official'/'jaka_a20.urdf').findall('.//joint') if j.attrib.get('type')=='revolute'])
    report[name]=dict(frames=len(seq),joint_limit_ok=bool(np.all(q>=limits[:,0]-1e-6) and np.all(q<=limits[:,1]+1e-6)),max_step_deg=float(np.degrees(np.max(np.abs(np.diff(q,axis=0))))),joint_speed_within_urdf_limit=bool(np.all(speeds<=allowed+1e-6)),max_tcp_error_mm=float(1000*max(err)),proxy_bowl_penetration_frames=len(crossing),penetration_examples=crossing[:10])
print(json.dumps(report,indent=2,ensure_ascii=False))
(Path(__file__).parent/'output'/'validation.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
