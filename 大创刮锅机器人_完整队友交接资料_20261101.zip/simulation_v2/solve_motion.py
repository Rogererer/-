"""Concept motion using JAKA's published A20 URDF and joint limits.

Units are metres/radians.  The pot is a dimensional placeholder pending a
readable version of the supplied SolidWorks bowl part.
"""
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import numpy as np
from scipy.optimize import least_squares
from scipy.spatial.transform import Rotation

ROOT = Path(__file__).parent
URDF = ROOT / 'a20_official' / 'jaka_a20.urdf'
OUT = ROOT / 'motion.json'

def T(xyz=(0,0,0), rpy=(0,0,0)):
    m=np.eye(4); m[:3,:3]=Rotation.from_euler('xyz',rpy).as_matrix(); m[:3,3]=xyz
    return m

def rot(axis, angle):
    m=np.eye(4); m[:3,:3]=Rotation.from_rotvec(axis*angle).as_matrix()
    return m

root=ET.parse(URDF).getroot()
joints=[]
for n in root.findall('joint'):
    if n.attrib.get('type')!='revolute': continue
    o=n.find('origin'); a=n.find('axis'); lim=n.find('limit')
    joints.append(dict(name=n.attrib['name'], origin=T(np.fromstring(o.attrib['xyz'],sep=' '),np.fromstring(o.attrib['rpy'],sep=' ')), axis=np.fromstring(a.attrib['xyz'],sep=' '), lo=float(lim.attrib['lower']),hi=float(lim.attrib['upper'])))

# Pot centre and A20 mounting face, relative to a shared floor frame.
BASE=np.array([-0.98,0.0,1.15]); BASE_T=T(BASE)
TIP=np.array([0,0,0.20,1.0]) # 200 mm scraper extension from the flange

def fk(q):
    m=BASE_T.copy(); mats=[m.copy()]
    for joint,angle in zip(joints,q):
        m=m@joint['origin']@rot(joint['axis'],angle)
        mats.append(m.copy())
    return mats

def tool(q):
    m=fk(q)[-1]
    return (m@TIP)[:3], m[:3,2]

lo=np.array([j['lo'] for j in joints]); hi=np.array([j['hi'] for j in joints]);

def solve(target, q0, axial=None):
    def residual(q):
        p,a=tool(q)
        r=list(8*(p-target))
        if axial is not None: r.extend(0.45*(a-axial))
        r.extend(np.array([.025,.025,.025,.025,.025,.12])*(q-q0))
        return r
    best=None
    seeds=[q0, np.zeros(6), np.array([0,-0.5,1,0,0,0]),np.array([0,0.8,-1,0,0,0])]
    for seed in seeds:
        x=least_squares(residual,np.clip(seed,lo+1e-4,hi-1e-4),bounds=(lo+1e-6,hi-1e-6),max_nfev=120,ftol=1e-7)
        err=np.linalg.norm(tool(x.x)[0]-target)
        score=err+0.03*np.linalg.norm(x.x-q0)
        if best is None or score<best[0]: best=(score,err,x.x)
        if err<0.006: break
    return best[2],best[1]

def main():
    # Contact line is 60 mm inside the assumed 650 mm rim radius.
    radius=0.59; height=0.95
    q=np.zeros(6); data=[]
    for scheme,angles in [('full',np.linspace(-math.pi,math.pi,73)),('half',np.linspace(math.pi/2,3*math.pi/2,37))]:
        frames=[]
        for i,theta in enumerate(angles):
            target=np.array([radius*math.cos(theta),radius*math.sin(theta),height])
            # Predominantly downward shaft, with some radial component.
            desired=np.array([-0.3*math.cos(theta),-0.3*math.sin(theta),-0.954]); desired/=np.linalg.norm(desired)
            q,err=solve(target,q,desired)
            frames.append(dict(theta=float(theta),q=q.tolist(),tip=tool(q)[0].tolist(),target=target.tolist(),error=float(err)))
        data.append(dict(scheme=scheme,frames=frames))
        print(scheme,'max error mm',round(max(f['error'] for f in frames)*1000,1),'mean',round(np.mean([f['error'] for f in frames])*1000,1))
    OUT.write_text(json.dumps(dict(base=BASE.tolist(),radius=radius,height=height,trajectories=data),indent=2),encoding='utf-8')

if __name__=='__main__': main()
